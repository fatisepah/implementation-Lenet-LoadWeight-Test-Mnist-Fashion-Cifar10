In this project, the weights of the network are already trained and saved, and then the desired model is built based on the Lenet-5 network, and the weights are loaded into it, and the network is tested with the test data, and the network is tested using the dataset. Mnist and Fashion Mnist and Cifar-10 are implemented. At the end of the Test section, Accuracy (99.1) of the network is printed.

در این پروژه وزنهای شبکه از قبل 
Train
 شده و 
Save
 شده اند و سپس مدل مورد نظر براساس شبکه 
Lenet-5
 ساخته شده و وزنهای در آن 
Load 
می شوند و با داده های تست  شبکه را تست کرده، و 
Test 
این شبکه با استفاده از 
Dataset Mnist و Fashion Mnist و Cifar-10
 پیاده سازی شده است.  در انتهای بخش 
Test آن
 Accuracy (99.1)
 شبکه چاپ می شود.